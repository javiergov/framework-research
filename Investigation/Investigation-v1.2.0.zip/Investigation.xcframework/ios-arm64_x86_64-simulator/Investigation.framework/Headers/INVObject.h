//
//  INVObject.h
//  Investigation
//
//  Created by Javier González Ovalle on 07-06-23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface INVObject : NSObject

@property (nonatomic, copy) NSString *name;

- (void)sayMyName;

@end

NS_ASSUME_NONNULL_END
