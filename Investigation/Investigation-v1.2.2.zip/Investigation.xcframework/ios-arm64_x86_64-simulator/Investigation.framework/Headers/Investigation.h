//
//  Investigation.h
//  Investigation
//
//  Created by Javier González Ovalle on 07-06-23.
//

#import <Foundation/Foundation.h>

//! Project version number for Investigation.
FOUNDATION_EXPORT double InvestigationVersionNumber;

//! Project version string for Investigation.
FOUNDATION_EXPORT const unsigned char InvestigationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Investigation/PublicHeader.h>
#import <Investigation/INVObject.h>

